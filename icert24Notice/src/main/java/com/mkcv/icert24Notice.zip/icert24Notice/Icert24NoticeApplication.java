package com.mkcv.icert24Notice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Icert24NoticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(Icert24NoticeApplication.class, args);
	}

}
