package com.mkcv.icert24Notice.controller;

import com.mkcv.icert24Notice.exception.NoticeNotFoundException;
import com.mkcv.icert24Notice.model.Notice;
import com.mkcv.icert24Notice.repository.NoticeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class NotceController {
    @Autowired
    private NoticeRepository noticeRepository;

    @PostMapping("/saveNotice")
    Notice newNotice(@RequestBody Notice newNotice){
        return noticeRepository.save(newNotice);
    }

    @GetMapping("/getNotices")
    List<Notice> getAllNotice(){
        return noticeRepository.findAll();
    }

    @GetMapping("/getNotice/{notice_seq}")
    Notice getNoticeById(@PathVariable Long notice_seq){
        return noticeRepository.findById(notice_seq)
                .orElseThrow(()->new NoticeNotFoundException(notice_seq));
    }
}
